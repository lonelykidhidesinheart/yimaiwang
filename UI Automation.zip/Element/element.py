class element:

    def __init__(self,driver,URL):
        self.driver = driver
        self.URL = URL

    def find_element(self,list):
        return self.driver.find_element(*list)

    def input_text(self,list,text):
        self.driver.find_element(*list).send_keys(text)

    def click(self,list):
        self.driver.find_element(*list).click()

    def Return_judgement(self,list):
        return self.driver.find_element(*list).text