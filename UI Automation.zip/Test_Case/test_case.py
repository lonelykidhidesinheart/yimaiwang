from yimaiwang.Technological_process.Technological_Process import Technological_process
import unittest,time,csv
from selenium import webdriver
class test_case(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Firefox()
        self.url = 'http://localhost:8080/ebuy/Home?action=index'
    def test_case(self):
        """商品详情页面购买商品"""
        text = '123w'
        text1 = '123456789'
        Verify = Technological_process.Purchasegoods(self,self.driver,self.url,text,text1)
        time.sleep(3)
        if self.assertEqual('购买成功',Verify):
            self.driver.get_screenshot_as_file(r'E:\PYTHON_yimaiwang\yimaiwang\bug_screenshot\购买商品.png')

    def tearDown(self):
        self.driver.quit()
    pass

