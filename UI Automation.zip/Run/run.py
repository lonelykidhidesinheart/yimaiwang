from yimaiwang.Test_Case import test_case

import unittest,time

import HTMLTestRunner

Test_directory = 'E:\PYTHON_yimaiwang\yimaiwang\Test_Case'
discover = unittest.defaultTestLoader.discover(Test_directory,pattern='test*.py')
Test = unittest.TestSuite()
Test.addTest(discover)
RUN = unittest.TextTestRunner()
if __name__ =='__main__':
    now = time.strftime("%Y-%m-%d-%H-%M-%S")
    Report_directory = 'E:\PYTHON_yimaiwang\yimaiwang\Presentation'
    file = Report_directory + '/' + now + "测试报告.html"
    fp = open(file,'wb')
    RUN = HTMLTestRunner.HTMLTestRunner(stream=fp, title="登录测试报告", description="用例测试情况")
    RUN.run(Test)
    fp.close()