from yimaiwang.Business.business import business
class Technological_process():
    def Purchasegoods(self,driver,URL,text,text1):
        PG = business(driver,URL)
        PG.Open_web_page()
        PG.Click_login_button()
        PG.Input_account(text)
        PG.Input_password(text1)
        PG.Click_login()
        PG.Click_merchandise()
        PG.Purchase_goods()
        return PG.Verify_purchase()
