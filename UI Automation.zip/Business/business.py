from yimaiwang.Element.element import *

class business(element):
    login_button = ('xpath','/html/body/div[1]/div/span[2]/span/a[1]') #首页登录按钮元素定位
    login = ('xpath','/html/body/div[4]/div[2]/div[2]/form/table/tbody/tr[4]/td[2]/input') #登录界面登录元素定位
    account = ('xpath','//*[@id="loginName"]') #账号元素定位
    password = ('xpath','//*[@id="password"]') #密码元素定位
    Home_products = ('xpath','/html/body/div[6]/div[4]/div[2]/ul/li[1]/div[3]/a') #首页商品点击元素定位
    Commodity_Button = ('xpath','/html/body/div[6]/div[2]/div[2]/div[6]/span/img') #购买商品按钮
    Verification = ('xpath','//*[@id="showMessage"]') #验证弹出购买成功
    def __init__(self,driver,URL):
        element.__init__(self,driver,URL)

    def Open_web_page(self):
        """打开网页 """
        self.driver.get(self.URL)

    def Click_login_button(self):
        """点击首页登录按钮"""
        self.click(self.login_button)

    def Input_account(self,text):
        """输入账号"""
        self.input_text(self.account,text)

    def Input_password(self,text):
        """输入密码"""
        self.input_text(self.password,text)

    def Click_login(self):
        """点击登录"""
        self.click(self.login)

    def Click_merchandise(self):
        """点击首页的一个商品进入商品商品详情页面"""
        self.click(self.Home_products)

    def Purchase_goods(self):
        """点击购买商品"""
        self.click(self.Commodity_Button)

    def Verify_purchase(self):
        """验证购买商品"""
        return self.Return_judgement(self.Verification)

